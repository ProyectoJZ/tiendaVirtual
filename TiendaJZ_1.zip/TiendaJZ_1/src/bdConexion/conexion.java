
package bdConexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class conexion {
    
    public static void main(String[] args) throws SQLException{
    String cadenaConexion="jdbc:mysql://localhost:3306/bd_tienda";
    try(
        Connection con=DriverManager.getConnection(cadenaConexion, "root","");
        Statement sent=con.createStatement()){
    
    
    sent.executeUpdate("insert into Producto(idProducto,nomProducto,desProducto,tallasProducto,"
            + "stockExistente,fechaStock,precioVenta,Imagen)values(1,'Camiseta','Camiseta de color blanco,tejido elastico'"
            + ",38,12,23.05.2020,12.95,1,)");
                
        
        
    }catch(SQLException e){
         e.printStackTrace();          
    }
    
    }
    
}
